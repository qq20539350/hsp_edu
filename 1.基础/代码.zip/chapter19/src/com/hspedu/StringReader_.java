package com.hspedu;

/**
 * @author 韩顺平
 * @version 1.0
 * 节点流
 */
public class StringReader_ extends Reader_ {
    public void readString() {
        System.out.println("读取字符串..");
    }

}
