package com.hspedu.dao_.dao;

import com.hspedu.dao_.domain.Actor;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class ActorDAO extends BasicDAO<Actor> {
    //1. 就有 BasicDAO 的方法
    //2. 根据业务需求，可以编写特有的方法.
}
