package com.hspedu.homework;

public class Homework03 {
    public static void main(String[] args) {
        Professor professor = new Professor("贾宝玉", 30, "高级职称", 30000, 1.3);
        professor.introduce();
    }
}

