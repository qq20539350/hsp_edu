package com.hspedu.homework;

public class Homework09 {
    public static void main(String[] args) {
        new LabeledPoint("Black",1929,230.07);
    }
}
