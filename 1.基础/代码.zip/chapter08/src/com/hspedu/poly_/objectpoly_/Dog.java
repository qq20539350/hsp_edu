package com.hspedu.poly_.objectpoly_;

public class Dog extends Animal {

    public void cry() {
        System.out.println("Dog cry() 小狗汪汪叫...");
    }
}
