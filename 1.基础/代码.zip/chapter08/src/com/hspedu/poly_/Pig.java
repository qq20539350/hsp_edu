package com.hspedu.poly_;

public class Pig extends Animal {
    public Pig(String name) {
        super(name);
    }
}
