package com.hspedu.poly_;

public class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
}
