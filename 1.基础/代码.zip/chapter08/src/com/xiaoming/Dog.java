package com.xiaoming;

public class Dog {
}
