package com.xiaoqiang;

public class Dog {
}
