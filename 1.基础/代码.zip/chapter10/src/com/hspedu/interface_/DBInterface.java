package com.hspedu.interface_;

public interface DBInterface { //项目经理

    public void connect();//连接方法
    public void close();//关闭连接
}
