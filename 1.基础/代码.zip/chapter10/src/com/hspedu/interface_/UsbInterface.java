package com.hspedu.interface_;

public interface UsbInterface { //接口
    //规定接口的相关方法,老师规定的.即规范...
    public void start();
    public void stop();
}
