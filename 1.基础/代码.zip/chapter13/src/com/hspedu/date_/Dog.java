package com.hspedu.date_;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Dog {
    private String name;
    private int age;

    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public void cry() {

    }
    class Air {

    }

    //说明一下diagram IDEA properties 的含义
    public void setAddress(String address) {

    }

    public double getSalary() {
        return 1.1;
    }
}
