package com.hspedu.wrapper;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class WrapperType {
    public static void main(String[] args) {

        //boolean -> Boolean
        //char -> Character
        //byte -> Byte
        //int -> Integer
        //long -> long
        //float -> Float
        //double -> Double
        //short -> Short
    }
}
