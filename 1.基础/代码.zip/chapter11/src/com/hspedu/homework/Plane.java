package com.hspedu.homework;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Plane implements Vehicles {
    @Override
    public void work() {
        System.out.println("过火焰山，使用飞机...");
    }
}
