package com.hspedu.homework;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Horse implements Vehicles {
    @Override
    public void work() {
        System.out.println(" 一般情况下，使用马儿前进...");
    }
}
